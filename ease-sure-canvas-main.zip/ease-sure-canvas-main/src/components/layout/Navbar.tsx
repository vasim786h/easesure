
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, Menu, Phone } from "lucide-react";
import Logo from "@/components/ui/Logo";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <nav className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <Logo />
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <div className="flex items-center space-x-6">
            <Link to="/health" className="text-gray-700 hover:text-easesure-primary transition-colors">Health</Link>
            <Link to="/life" className="text-gray-700 hover:text-easesure-primary transition-colors">Life</Link>
            <Link to="/motor" className="text-gray-700 hover:text-easesure-primary transition-colors">Motor</Link>
            <Link to="/travel" className="text-gray-700 hover:text-easesure-primary transition-colors">Travel</Link>
            <Link to="/business" className="text-gray-700 hover:text-easesure-primary transition-colors">Business</Link>
            <Link to="/about" className="text-gray-700 hover:text-easesure-primary transition-colors">About</Link>
            <Link to="/contact" className="text-gray-700 hover:text-easesure-primary transition-colors">Contact</Link>
          </div>

          <div className="flex items-center space-x-4">
            <Link to="/login">
              <Button variant="outline" className="border-easesure-primary text-easesure-primary hover:bg-easesure-primary hover:text-white">
                Log in
              </Button>
            </Link>
            <Link to="/get-insurance">
              <Button className="bg-easesure-primary hover:bg-easesure-secondary transition-colors">
                Get Insurance
              </Button>
            </Link>
          </div>
        </div>

        {/* Mobile menu button */}
        <div className="flex items-center md:hidden">
          <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Toggle menu">
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white py-4 px-4 shadow-lg">
          <div className="flex flex-col space-y-4">
            <Link to="/health" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Health</Link>
            <Link to="/life" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Life</Link>
            <Link to="/motor" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Motor</Link>
            <Link to="/travel" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Travel</Link>
            <Link to="/business" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Business</Link>
            <Link to="/about" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">About</Link>
            <Link to="/contact" className="text-gray-700 hover:text-easesure-primary py-2 transition-colors">Contact</Link>
          </div>
          <div className="mt-6 flex flex-col space-y-4">
            <Link to="/login">
              <Button variant="outline" className="w-full border-easesure-primary text-easesure-primary hover:bg-easesure-primary hover:text-white">
                Log in
              </Button>
            </Link>
            <Link to="/get-insurance">
              <Button className="w-full bg-easesure-primary hover:bg-easesure-secondary transition-colors">
                Get Insurance
              </Button>
            </Link>
          </div>
          <div className="mt-6 flex items-center text-easesure-primary py-2">
            <Phone className="h-4 w-4 mr-2" />
            <span>1800-266-0101</span>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
