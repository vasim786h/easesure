
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone } from "lucide-react";
import Logo from "@/components/ui/Logo";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-easesure-dark text-white pt-16 pb-8">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Logo className="mb-4" />
            <p className="mb-6 text-gray-300">
              Your trusted insurance partner. We make insurance simple, affordable, and accessible for everyone.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-easesure-secondary">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-easesure-secondary">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-easesure-secondary">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-easesure-secondary">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4">Insurance</h4>
            <ul className="space-y-2 text-gray-300">
              <li><Link to="/health" className="hover:text-easesure-secondary">Health Insurance</Link></li>
              <li><Link to="/life" className="hover:text-easesure-secondary">Life Insurance</Link></li>
              <li><Link to="/motor" className="hover:text-easesure-secondary">Motor Insurance</Link></li>
              <li><Link to="/travel" className="hover:text-easesure-secondary">Travel Insurance</Link></li>
              <li><Link to="/business" className="hover:text-easesure-secondary">Business Insurance</Link></li>
              <li><Link to="/services" className="hover:text-easesure-secondary">All Services</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4">Company</h4>
            <ul className="space-y-2 text-gray-300">
              <li><Link to="/about" className="hover:text-easesure-secondary">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-easesure-secondary">Contact Us</Link></li>
              <li><Link to="/terms" className="hover:text-easesure-secondary">Terms & Conditions</Link></li>
              <li><Link to="/privacy" className="hover:text-easesure-secondary">Privacy Policy</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-medium mb-4">Support</h4>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-center">
                <Phone className="w-4 h-4 mr-2" />
                <span>1800-266-0101</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                <a href="mailto:support@easesure.com" className="hover:text-easesure-secondary">support@easesure.com</a>
              </li>
            </ul>
            <div className="mt-4">
              <h5 className="font-medium mb-2">Working Hours</h5>
              <p className="text-gray-300">Mon - Sat: 9:00 AM - 9:00 PM</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="text-gray-400 text-sm">
              © 2025 EaseSure Insurance. All rights reserved.
            </div>
            <div className="flex space-x-4 text-gray-400 text-sm justify-start md:justify-end">
              <Link to="/terms" className="hover:text-easesure-secondary">Terms & Conditions</Link>
              <Link to="/privacy" className="hover:text-easesure-secondary">Privacy Policy</Link>
              <a href="#" className="hover:text-easesure-secondary">Sitemap</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
