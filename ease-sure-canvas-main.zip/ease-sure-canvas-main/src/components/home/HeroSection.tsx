
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, Car, Heart, Home, Plane, Briefcase } from "lucide-react";

const HeroSection = () => {
  const [selectedInsurance, setSelectedInsurance] = useState("health");

  return (
    <section className="bg-gradient-to-r from-easesure-accent to-white py-16 md:py-24">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-easesure-dark mb-4">
              Find the <span className="text-easesure-primary">perfect insurance</span> for your needs
            </h1>
            <p className="text-lg md:text-xl mb-8 text-gray-700">
              Compare quotes from 40+ insurance companies and save up to 45% on premiums
            </p>

            <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
              <div className="flex flex-wrap gap-2 mb-6">
                <Button
                  variant={selectedInsurance === "health" ? "default" : "outline"}
                  className={`flex items-center ${selectedInsurance === "health" ? "bg-easesure-primary" : "border-gray-300"}`}
                  onClick={() => setSelectedInsurance("health")}
                >
                  <Heart className="h-4 w-4 mr-2" /> Health
                </Button>
                <Button
                  variant={selectedInsurance === "car" ? "default" : "outline"}
                  className={`flex items-center ${selectedInsurance === "car" ? "bg-easesure-primary" : "border-gray-300"}`}
                  onClick={() => setSelectedInsurance("car")}
                >
                  <Car className="h-4 w-4 mr-2" /> Car
                </Button>
                <Button
                  variant={selectedInsurance === "home" ? "default" : "outline"}
                  className={`flex items-center ${selectedInsurance === "home" ? "bg-easesure-primary" : "border-gray-300"}`}
                  onClick={() => setSelectedInsurance("home")}
                >
                  <Home className="h-4 w-4 mr-2" /> Home
                </Button>
                <Button
                  variant={selectedInsurance === "travel" ? "default" : "outline"}
                  className={`flex items-center ${selectedInsurance === "travel" ? "bg-easesure-primary" : "border-gray-300"}`}
                  onClick={() => setSelectedInsurance("travel")}
                >
                  <Plane className="h-4 w-4 mr-2" /> Travel
                </Button>
                <Button
                  variant={selectedInsurance === "business" ? "default" : "outline"}
                  className={`flex items-center ${selectedInsurance === "business" ? "bg-easesure-primary" : "border-gray-300"}`}
                  onClick={() => setSelectedInsurance("business")}
                >
                  <Briefcase className="h-4 w-4 mr-2" /> Business
                </Button>
              </div>

              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Enter your pincode"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-easesure-primary"
                />
              </div>

              <Button className="w-full bg-easesure-primary hover:bg-easesure-secondary transition-colors text-lg py-6">
                View Plans <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-4 items-center justify-center md:justify-start">
              <div className="flex items-center">
                <div className="bg-white rounded-full p-1 shadow-sm">
                  <svg className="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </div>
                <div className="ml-2">
                  <p className="text-sm font-medium">4.8/5 Rating</p>
                </div>
              </div>

              <div className="flex items-center">
                <div className="bg-white rounded-full p-1 shadow-sm">
                  <svg className="h-5 w-5 text-easesure-primary" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-2">
                  <p className="text-sm font-medium">3M+ Happy Customers</p>
                </div>
              </div>

              <div className="flex items-center">
                <div className="bg-white rounded-full p-1 shadow-sm">
                  <svg className="h-5 w-5 text-easesure-primary" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-2">
                  <p className="text-sm font-medium">10 Min Claim Process</p>
                </div>
              </div>
            </div>
          </div>

          <div className="hidden lg:block">
            <div className="relative">
              <div className="absolute -top-10 -left-10 w-24 h-24 bg-easesure-secondary rounded-full opacity-20 animate-float"></div>
              <div className="absolute bottom-10 -right-10 w-32 h-32 bg-easesure-primary rounded-full opacity-20 animate-float" style={{ animationDelay: "1s" }}></div>
              <img 
                src="https://images.unsplash.com/photo-1590856029826-c7a73142bbf1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZmFtaWx5JTIwaW5zdXJhbmNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=600&q=60" 
                alt="Happy family with insurance protection" 
                className="rounded-xl shadow-2xl z-10 relative"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
