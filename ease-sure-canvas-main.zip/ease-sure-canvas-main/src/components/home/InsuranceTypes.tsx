
import { Car, Heart, Home, Plane, Briefcase, Shield } from "lucide-react";
import InsuranceCard from "@/components/ui/InsuranceCard";
import { Link } from "react-router-dom";

const InsuranceTypes = () => {
  const insuranceProducts = [
    {
      title: "Health Insurance",
      description: "Comprehensive health coverage for you and your family with cashless claims at 10,000+ hospitals.",
      icon: <Heart className="h-6 w-6 text-white" />,
      color: "bg-red-500",
      link: "/learn/health"
    },
    {
      title: "Car Insurance",
      description: "Protect your vehicle with comprehensive coverage, roadside assistance, and quick claim settlement.",
      icon: <Car className="h-6 w-6 text-white" />,
      color: "bg-blue-500",
      link: "/motor"
    },
    {
      title: "Home Insurance",
      description: "Secure your home against natural disasters, theft, and damage with our comprehensive plans.",
      icon: <Home className="h-6 w-6 text-white" />,
      color: "bg-green-500",
      link: "/business"
    },
    {
      title: "Travel Insurance",
      description: "Enjoy your trips worry-free with coverage for medical emergencies, trip cancellations, and more.",
      icon: <Plane className="h-6 w-6 text-white" />,
      color: "bg-yellow-500",
      link: "/travel"
    },
    {
      title: "Business Insurance",
      description: "Tailored insurance solutions for businesses of all sizes to protect against various risks.",
      icon: <Briefcase className="h-6 w-6 text-white" />,
      color: "bg-purple-500",
      link: "/business"
    },
    {
      title: "Life Insurance",
      description: "Secure your family's financial future with our range of life insurance plans and investment options.",
      icon: <Shield className="h-6 w-6 text-white" />,
      color: "bg-easesure-secondary",
      link: "/life"
    },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Insurance Solutions for Every Need</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Compare and choose from a wide range of insurance products tailored to your specific requirements
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {insuranceProducts.map((product, index) => (
            <Link to={product.link} key={index} className="block hover:no-underline">
              <InsuranceCard
                title={product.title}
                description={product.description}
                icon={product.icon}
                color={product.color}
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default InsuranceTypes;
