
import TestimonialCard from "../ui/TestimonialCard";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Priya Sharma",
      location: "Delhi",
      quote: "EaseSure made finding the right health insurance for my family so simple. Their comparison tool helped me save nearly 30% on premiums!",
      rating: 5
    },
    {
      name: "Rajesh Khanna",
      location: "Mumbai",
      quote: "I was in a car accident and was worried about the claim process, but EaseSure's team guided me through every step and my claim was settled in just 3 days.",
      rating: 5
    },
    {
      name: "Ananya Patel",
      location: "Bangalore",
      quote: "The customer service is exceptional. When I had questions about my policy, their advisors took the time to explain everything clearly.",
      rating: 4
    }
  ];

  return (
    <section className="py-16 bg-easesure-accent">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. See what our satisfied customers have to say about their experience with EaseSure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard
              key={index}
              name={testimonial.name}
              location={testimonial.location}
              quote={testimonial.quote}
              rating={testimonial.rating}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
