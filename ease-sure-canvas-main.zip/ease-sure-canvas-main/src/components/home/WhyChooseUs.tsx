
import { CheckCircle, ThumbsUp, Clock, TrendingUp, Headphones, Shield } from "lucide-react";

const WhyChooseUs = () => {
  const benefits = [
    {
      icon: <CheckCircle className="h-10 w-10 text-easesure-primary" />,
      title: "Easy Comparison",
      description: "Compare features and prices from 40+ insurers to find the best policy for your needs."
    },
    {
      icon: <ThumbsUp className="h-10 w-10 text-easesure-primary" />,
      title: "Unbiased Advice",
      description: "Our expert advisors help you make informed decisions with transparent recommendations."
    },
    {
      icon: <Clock className="h-10 w-10 text-easesure-primary" />,
      title: "Quick Processing",
      description: "Fast policy issuance and claims settlement with minimal documentation."
    },
    {
      icon: <TrendingUp className="h-10 w-10 text-easesure-primary" />,
      title: "Best Prices",
      description: "Save up to 45% on premiums with exclusive deals and discounts from our insurance partners."
    },
    {
      icon: <Headphones className="h-10 w-10 text-easesure-primary" />,
      title: "Dedicated Support",
      description: "Get help with policy selection, renewals, and claims through our 24/7 customer support."
    },
    {
      icon: <Shield className="h-10 w-10 text-easesure-primary" />,
      title: "100% Secure",
      description: "Your data is protected with bank-grade security and is never shared without your consent."
    }
  ];

  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose EaseSure</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We're dedicated to making insurance accessible, affordable, and easy to understand
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="mb-4">{benefit.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
