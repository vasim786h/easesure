
import { ArrowRight } from "lucide-react";

interface InsuranceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const InsuranceCard = ({ title, description, icon, color }: InsuranceCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 flex flex-col h-full">
      <div className={`${color} rounded-full p-3 w-fit mb-4`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600 mb-4 flex-grow">{description}</p>
      <div className="text-easesure-primary font-medium flex items-center group">
        Learn more
        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
      </div>
    </div>
  );
};

export default InsuranceCard;
