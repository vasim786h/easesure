
import { Star } from "lucide-react";

interface TestimonialCardProps {
  name: string;
  location: string;
  quote: string;
  rating: number;
  image?: string;
}

const TestimonialCard = ({ name, location, quote, rating, image }: TestimonialCardProps) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
      <div className="flex items-center mb-4">
        <div className="flex space-x-0.5">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i}
              className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
            />
          ))}
        </div>
      </div>
      
      <p className="text-gray-700 mb-6 italic">"{quote}"</p>
      
      <div className="flex items-center">
        {image ? (
          <img 
            src={image} 
            alt={name} 
            className="h-10 w-10 rounded-full object-cover mr-3"
          />
        ) : (
          <div className="h-10 w-10 rounded-full bg-easesure-primary text-white flex items-center justify-center mr-3">
            {name[0]}
          </div>
        )}
        <div>
          <h4 className="font-semibold">{name}</h4>
          <p className="text-sm text-gray-500">{location}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;
