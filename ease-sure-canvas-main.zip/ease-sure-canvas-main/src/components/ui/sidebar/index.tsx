
import * as React from "react"
import { TooltipProvider } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"

import {
  SidebarContext,
  SidebarProvider,
  useSidebar
} from "./sidebar-context"

import {
  Sidebar,
  SidebarRail,
  SidebarInset
} from "./sidebar"

import {
  SidebarTrigger,
  SidebarInput,
  SidebarHeader,
  SidebarFooter,
  SidebarSeparator,
  SidebarContent
} from "./sidebar-elements"

import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupAction,
  SidebarGroupContent
} from "./sidebar-group"

import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuSkeleton,
  sidebarMenuButtonVariants
} from "./sidebar-menu"

import {
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton
} from "./sidebar-submenu"

// Simplified wrapper for SidebarProvider that also provides TooltipProvider
const EnhancedSidebarProvider = React.forwardRef<
  HTMLDivElement,
  React.ComponentPropsWithoutRef<typeof SidebarProvider>
>(function EnhancedSidebarProvider(props, ref) {
  return (
    <SidebarProvider
      ref={ref}
      className={cn(
        "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
        props.className
      )}
      {...props}
    >
      <TooltipProvider delayDuration={0}>
        {props.children}
      </TooltipProvider>
    </SidebarProvider>
  );
});

// Export everything
export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  EnhancedSidebarProvider as SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
};

// Type reexport
export type { SidebarContext };
