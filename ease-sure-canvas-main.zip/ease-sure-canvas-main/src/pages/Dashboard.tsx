import { useState } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Shield, FileText, Bell, Settings, LogOut, ChevronRight, Bookmark, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

// Mock data
const userPolicies = [
  {
    id: "POL-1234567",
    type: "Health Insurance",
    plan: "Family Floater Plan",
    premium: "₹25,000",
    status: "Active",
    renewalDate: "2026-01-15",
    coverAmount: "₹10,00,000"
  },
  {
    id: "POL-2345678",
    type: "Car Insurance",
    plan: "Comprehensive Cover",
    premium: "₹8,500",
    status: "Active",
    renewalDate: "2025-08-22",
    coverAmount: "₹5,00,000"
  },
  {
    id: "POL-3456789",
    type: "Life Insurance",
    plan: "Term Plan",
    premium: "₹12,000",
    status: "Active",
    renewalDate: "2045-05-10",
    coverAmount: "₹1,00,00,000"
  }
];

const claimHistory = [
  {
    id: "CLM-1234567",
    policyId: "POL-1234567",
    type: "Health Insurance",
    date: "2025-01-10",
    amount: "₹85,000",
    status: "Approved",
    description: "Hospital admission for appendix surgery"
  },
  {
    id: "CLM-2345678",
    policyId: "POL-2345678",
    type: "Car Insurance",
    date: "2024-11-25",
    amount: "₹25,000",
    status: "In Process",
    description: "Minor accident repair"
  },
  {
    id: "CLM-3456789",
    policyId: "POL-1234567",
    type: "Health Insurance",
    date: "2024-09-18",
    amount: "₹12,000",
    status: "Approved",
    description: "Medical tests and consultation"
  }
];

const notifications = [
  {
    id: 1,
    message: "Your health insurance policy POL-1234567 is due for renewal in 30 days.",
    time: "2 days ago",
    read: false,
    type: "renewal"
  },
  {
    id: 2,
    message: "Your claim CLM-2345678 is being processed. We'll update you soon.",
    time: "1 week ago",
    read: true,
    type: "claim"
  },
  {
    id: 3,
    message: "New health insurance plans available with enhanced coverage. Check them out!",
    time: "2 weeks ago",
    read: true,
    type: "promotion"
  }
];

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8 bg-gray-50">
        <div className="container">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="w-full md:w-64 shrink-0">
              <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
                <div className="flex flex-col items-center text-center mb-4">
                  <Avatar className="h-20 w-20 mb-4">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-easesure-primary text-white text-xl">JD</AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-semibold">John Doe</h2>
                  <p className="text-gray-500">john.doe@example.com</p>
                </div>
                <div className="flex justify-center space-x-2 border-t pt-4 mt-2">
                  <Button variant="outline" size="sm" className="w-full">Edit Profile</Button>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <nav className="flex flex-col">
                  <button 
                    className={`flex items-center px-6 py-3 hover:bg-gray-50 ${activeTab === "overview" ? "bg-easesure-primary/10 border-l-4 border-easesure-primary" : ""}`} 
                    onClick={() => setActiveTab("overview")}
                  >
                    <Shield className={`h-5 w-5 mr-3 ${activeTab === "overview" ? "text-easesure-primary" : "text-gray-500"}`} />
                    <span className={activeTab === "overview" ? "font-medium text-easesure-primary" : "text-gray-700"}>Overview</span>
                  </button>
                  <button 
                    className={`flex items-center px-6 py-3 hover:bg-gray-50 ${activeTab === "policies" ? "bg-easesure-primary/10 border-l-4 border-easesure-primary" : ""}`} 
                    onClick={() => setActiveTab("policies")}
                  >
                    <FileText className={`h-5 w-5 mr-3 ${activeTab === "policies" ? "text-easesure-primary" : "text-gray-500"}`} />
                    <span className={activeTab === "policies" ? "font-medium text-easesure-primary" : "text-gray-700"}>My Policies</span>
                  </button>
                  <button 
                    className={`flex items-center px-6 py-3 hover:bg-gray-50 ${activeTab === "claims" ? "bg-easesure-primary/10 border-l-4 border-easesure-primary" : ""}`} 
                    onClick={() => setActiveTab("claims")}
                  >
                    <CheckCircle className={`h-5 w-5 mr-3 ${activeTab === "claims" ? "text-easesure-primary" : "text-gray-500"}`} />
                    <span className={activeTab === "claims" ? "font-medium text-easesure-primary" : "text-gray-700"}>Claims</span>
                  </button>
                  <button 
                    className={`flex items-center px-6 py-3 hover:bg-gray-50 ${activeTab === "notifications" ? "bg-easesure-primary/10 border-l-4 border-easesure-primary" : ""}`} 
                    onClick={() => setActiveTab("notifications")}
                  >
                    <Bell className={`h-5 w-5 mr-3 ${activeTab === "notifications" ? "text-easesure-primary" : "text-gray-500"}`} />
                    <span className={activeTab === "notifications" ? "font-medium text-easesure-primary" : "text-gray-700"}>Notifications</span>
                    <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">2</span>
                  </button>
                  <button 
                    className={`flex items-center px-6 py-3 hover:bg-gray-50 ${activeTab === "settings" ? "bg-easesure-primary/10 border-l-4 border-easesure-primary" : ""}`} 
                    onClick={() => setActiveTab("settings")}
                  >
                    <Settings className={`h-5 w-5 mr-3 ${activeTab === "settings" ? "text-easesure-primary" : "text-gray-500"}`} />
                    <span className={activeTab === "settings" ? "font-medium text-easesure-primary" : "text-gray-700"}>Settings</span>
                  </button>
                  <button className="flex items-center px-6 py-3 text-red-600 hover:bg-red-50">
                    <LogOut className="h-5 w-5 mr-3" />
                    <span>Logout</span>
                  </button>
                </nav>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="flex-grow">
              {/* Overview Tab */}
              {activeTab === "overview" && (
                <div className="space-y-6">
                  <h1 className="text-2xl font-bold mb-6">Dashboard Overview</h1>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Active Policies</CardTitle>
                        <CardDescription>Your current insurance coverage</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-easesure-primary">3</div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Upcoming Renewals</CardTitle>
                        <CardDescription>Policies due for renewal</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-amber-500">1</div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Recent Claims</CardTitle>
                        <CardDescription>In the last 12 months</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-4xl font-bold text-blue-500">3</div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="md:col-span-2">
                      <CardHeader>
                        <CardTitle>Recent Policies</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {userPolicies.slice(0, 2).map((policy) => (
                            <div key={policy.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                              <div>
                                <h4 className="font-medium">{policy.type}</h4>
                                <p className="text-sm text-gray-500">{policy.plan}</p>
                              </div>
                              <div className="text-right">
                                <div className={`text-sm font-medium ${policy.status === "Active" ? "text-green-600" : "text-amber-600"}`}>
                                  {policy.status}
                                </div>
                                <p className="text-sm text-gray-500">Renewal: {new Date(policy.renewalDate).toLocaleDateString()}</p>
                              </div>
                            </div>
                          ))}
                          <Button variant="outline" className="w-full mt-2" onClick={() => setActiveTab("policies")}>
                            View All Policies <ChevronRight className="ml-1 h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Important Notifications</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {notifications.filter(n => !n.read).slice(0, 3).map((notification) => (
                            <div key={notification.id} className="p-3 border rounded-lg bg-easesure-primary/5 border-easesure-primary/20">
                              <p className="text-sm">{notification.message}</p>
                              <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                            </div>
                          ))}
                          {notifications.filter(n => !n.read).length === 0 && (
                            <p className="text-center text-gray-500 py-2">No new notifications</p>
                          )}
                          <Button variant="outline" className="w-full mt-2" onClick={() => setActiveTab("notifications")}>
                            View All Notifications <ChevronRight className="ml-1 h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Button variant="outline" className="flex flex-col h-auto py-4">
                          <FileText className="h-6 w-6 mb-2" />
                          <span>Download Policy</span>
                        </Button>
                        <Button variant="outline" className="flex flex-col h-auto py-4">
                          <CheckCircle className="h-6 w-6 mb-2" />
                          <span>File a Claim</span>
                        </Button>
                        <Button variant="outline" className="flex flex-col h-auto py-4">
                          <Bookmark className="h-6 w-6 mb-2" />
                          <span>Save Quote</span>
                        </Button>
                        <Button variant="outline" className="flex flex-col h-auto py-4">
                          <Clock className="h-6 w-6 mb-2" />
                          <span>Renew Policy</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
              
              {/* Policies Tab */}
              {activeTab === "policies" && (
                <div>
                  <h1 className="text-2xl font-bold mb-6">My Policies</h1>
                  <Tabs defaultValue="active">
                    <TabsList className="mb-4">
                      <TabsTrigger value="active">Active</TabsTrigger>
                      <TabsTrigger value="pending">Pending</TabsTrigger>
                      <TabsTrigger value="expired">Expired</TabsTrigger>
                    </TabsList>
                    <TabsContent value="active" className="space-y-4">
                      {userPolicies.map((policy) => (
                        <Card key={policy.id}>
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row md:items-center justify-between">
                              <div>
                                <p className="text-xs text-gray-500">Policy ID: {policy.id}</p>
                                <h3 className="text-lg font-semibold mt-1">{policy.type}</h3>
                                <p className="text-sm text-gray-700">{policy.plan}</p>
                              </div>
                              <div className="md:text-right mt-2 md:mt-0">
                                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  {policy.status}
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                              <div>
                                <p className="text-xs text-gray-500">Annual Premium</p>
                                <p className="text-base font-medium">{policy.premium}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Sum Insured</p>
                                <p className="text-base font-medium">{policy.coverAmount}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Renewal Date</p>
                                <p className="text-base font-medium">{new Date(policy.renewalDate).toLocaleDateString()}</p>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mt-6">
                              <Button variant="outline" size="sm">View Details</Button>
                              <Button variant="outline" size="sm">Download Policy</Button>
                              <Button size="sm" className="bg-easesure-primary hover:bg-easesure-secondary">Renew Policy</Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>
                    <TabsContent value="pending">
                      <div className="flex flex-col items-center justify-center text-center py-12">
                        <div className="bg-gray-100 p-4 rounded-full mb-4">
                          <Clock className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="text-xl font-medium mb-2">No Pending Policies</h3>
                        <p className="text-gray-500 max-w-sm">
                          You don't have any pending policy applications at the moment.
                        </p>
                        <Button className="mt-4 bg-easesure-primary hover:bg-easesure-secondary">Get a New Quote</Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="expired">
                      <div className="flex flex-col items-center justify-center text-center py-12">
                        <div className="bg-gray-100 p-4 rounded-full mb-4">
                          <AlertCircle className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="text-xl font-medium mb-2">No Expired Policies</h3>
                        <p className="text-gray-500 max-w-sm">
                          You don't have any expired policies. We'll notify you when your policies are approaching expiration.
                        </p>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
              
              {/* Claims Tab */}
              {activeTab === "claims" && (
                <div>
                  <h1 className="text-2xl font-bold mb-6">Claims History</h1>
                  <Tabs defaultValue="all">
                    <TabsList className="mb-4">
                      <TabsTrigger value="all">All Claims</TabsTrigger>
                      <TabsTrigger value="approved">Approved</TabsTrigger>
                      <TabsTrigger value="processing">In Process</TabsTrigger>
                      <TabsTrigger value="rejected">Rejected</TabsTrigger>
                    </TabsList>
                    <TabsContent value="all" className="space-y-4">
                      {claimHistory.map((claim) => (
                        <Card key={claim.id}>
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row md:items-center justify-between">
                              <div>
                                <p className="text-xs text-gray-500">Claim ID: {claim.id}</p>
                                <h3 className="text-lg font-semibold mt-1">{claim.type}</h3>
                                <p className="text-sm text-gray-700">{claim.description}</p>
                              </div>
                              <div className="md:text-right mt-2 md:mt-0">
                                <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  claim.status === "Approved" 
                                    ? "bg-green-100 text-green-800" 
                                    : claim.status === "In Process" 
                                    ? "bg-amber-100 text-amber-800" 
                                    : "bg-red-100 text-red-800"
                                }`}>
                                  {claim.status}
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                              <div>
                                <p className="text-xs text-gray-500">Claim Date</p>
                                <p className="text-base font-medium">{new Date(claim.date).toLocaleDateString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Policy ID</p>
                                <p className="text-base font-medium">{claim.policyId}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Claim Amount</p>
                                <p className="text-base font-medium">{claim.amount}</p>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mt-6">
                              <Button variant="outline" size="sm">View Details</Button>
                              <Button variant="outline" size="sm">Download Documents</Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>
                    <TabsContent value="approved">
                      {claimHistory.filter(c => c.status === "Approved").map((claim) => (
                        <Card key={claim.id} className="mb-4">
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row md:items-center justify-between">
                              <div>
                                <p className="text-xs text-gray-500">Claim ID: {claim.id}</p>
                                <h3 className="text-lg font-semibold mt-1">{claim.type}</h3>
                                <p className="text-sm text-gray-700">{claim.description}</p>
                              </div>
                              <div className="md:text-right mt-2 md:mt-0">
                                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  {claim.status}
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                              <div>
                                <p className="text-xs text-gray-500">Claim Date</p>
                                <p className="text-base font-medium">{new Date(claim.date).toLocaleDateString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Policy ID</p>
                                <p className="text-base font-medium">{claim.policyId}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Claim Amount</p>
                                <p className="text-base font-medium">{claim.amount}</p>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mt-6">
                              <Button variant="outline" size="sm">View Details</Button>
                              <Button variant="outline" size="sm">Download Documents</Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>
                    <TabsContent value="processing">
                      {claimHistory.filter(c => c.status === "In Process").map((claim) => (
                        <Card key={claim.id} className="mb-4">
                          <CardContent className="p-6">
                            <div className="flex flex-col md:flex-row md:items-center justify-between">
                              <div>
                                <p className="text-xs text-gray-500">Claim ID: {claim.id}</p>
                                <h3 className="text-lg font-semibold mt-1">{claim.type}</h3>
                                <p className="text-sm text-gray-700">{claim.description}</p>
                              </div>
                              <div className="md:text-right mt-2 md:mt-0">
                                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                                  {claim.status}
                                </div>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                              <div>
                                <p className="text-xs text-gray-500">Claim Date</p>
                                <p className="text-base font-medium">{new Date(claim.date).toLocaleDateString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Policy ID</p>
                                <p className="text-base font-medium">{claim.policyId}</p>
                              </div>
                              <div>
                                <p className="text-xs text-gray-500">Claim Amount</p>
                                <p className="text-base font-medium">{claim.amount}</p>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2 mt-6">
                              <Button variant="outline" size="sm">View Details</Button>
                              <Button variant="outline" size="sm">Upload Documents</Button>
                              <Button size="sm" className="bg-easesure-primary hover:bg-easesure-secondary">Track Status</Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>
                    <TabsContent value="rejected">
                      <div className="flex flex-col items-center justify-center text-center py-12">
                        <div className="bg-gray-100 p-4 rounded-full mb-4">
                          <AlertCircle className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="text-xl font-medium mb-2">No Rejected Claims</h3>
                        <p className="text-gray-500 max-w-sm">
                          You don't have any rejected claims.
                        </p>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
              
              {/* Notifications Tab */}
              {activeTab === "notifications" && (
                <div>
                  <h1 className="text-2xl font-bold mb-6">Notifications</h1>
                  <Card>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {notifications.map((notification) => (
                          <div 
                            key={notification.id} 
                            className={`p-4 border rounded-lg ${!notification.read ? "bg-easesure-primary/5 border-easesure-primary/20" : "bg-white"}`}
                          >
                            <div className="flex items-start">
                              <div className={`p-2 rounded-full mr-3 ${
                                notification.type === "renewal" 
                                  ? "bg-amber-100" 
                                  : notification.type === "claim" 
                                  ? "bg-blue-100" 
                                  : "bg-green-100"
                              }`}>
                                {notification.type === "renewal" && <Clock className="h-4 w-4 text-amber-600" />}
                                {notification.type === "claim" && <FileText className="h-4 w-4 text-blue-600" />}
                                {notification.type === "promotion" && <Bell className="h-4 w-4 text-green-600" />}
                              </div>
                              <div className="flex-grow">
                                <p className={`${!notification.read ? "font-medium" : ""}`}>{notification.message}</p>
                                <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                              </div>
                              {!notification.read && (
                                <div className="ml-2">
                                  <div className="h-2 w-2 bg-easesure-primary rounded-full"></div>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
              
              {/* Settings Tab */}
              {activeTab === "settings" && (
                <div>
                  <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Personal Information</CardTitle>
                        <CardDescription>Manage your account details</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid gap-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <Label>First Name</Label>
                              <Input defaultValue="John" />
                            </div>
                            <div>
                              <Label>Last Name</Label>
                              <Input defaultValue="Doe" />
                            </div>
                            <div>
                              <Label>Email Address</Label>
                              <Input defaultValue="john.doe@example.com" />
                            </div>
                            <div>
                              <Label>Phone Number</Label>
                              <Input defaultValue="+91 9876543210" />
                            </div>
                          </div>
                          <div>
                            <Button className="bg-easesure-primary hover:bg-easesure-secondary">Save Changes</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Password</CardTitle>
                        <CardDescription>Update your password</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid gap-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <Label>Current Password</Label>
                              <Input type="password" />
                            </div>
                            <div className="md:col-span-2">
                              <Label>New Password</Label>
                              <Input type="password" />
                            </div>
                            <div className="md:col-span-2">
                              <Label>Confirm New Password</Label>
                              <Input type="password" />
                            </div>
                          </div>
                          <div>
                            <Button className="bg-easesure-primary hover:bg-easesure-secondary">Update Password</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Notifications</CardTitle>
                        <CardDescription>Manage your notification preferences</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-sm font-medium">Policy Renewals</h4>
                              <p className="text-sm text-gray-500">Get notifications about upcoming policy renewals</p>
                            </div>
                            <div>
                              <Input type="checkbox" className="toggle" defaultChecked />
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-sm font-medium">Claim Updates</h4>
                              <p className="text-sm text-gray-500">Get updates about your claim status</p>
                            </div>
                            <div>
                              <Input type="checkbox" className="toggle" defaultChecked />
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-sm font-medium">Special Offers</h4>
                              <p className="text-sm text-gray-500">Receive notifications about special offers and promotions</p>
                            </div>
                            <div>
                              <Input type="checkbox" className="toggle" />
                            </div>
                          </div>
                          <Button className="bg-easesure-primary hover:bg-easesure-secondary">Save Preferences</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
