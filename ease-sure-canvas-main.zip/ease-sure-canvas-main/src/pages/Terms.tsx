
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const Terms = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-8">Terms and Conditions</h1>
            <div className="bg-white rounded-xl shadow-sm p-8 space-y-8">
              <div>
                <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
                <p className="text-gray-700 mb-3">
                  Welcome to EaseSure Insurance. These Terms and Conditions govern your use of our website and services. By accessing or using our website and services, you agree to be bound by these Terms.
                </p>
                <p className="text-gray-700">
                  Please read these Terms carefully before using our website or services. If you do not agree to all of these Terms, you must not access or use our website or services.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">2. Definitions</h2>
                <p className="text-gray-700 mb-3">
                  "Company", "We", "Us", "Our" refers to EaseSure Insurance.
                </p>
                <p className="text-gray-700 mb-3">
                  "User", "You", "Your" refers to individuals or entities accessing or using our website and services.
                </p>
                <p className="text-gray-700 mb-3">
                  "Services" refers to insurance products, information, tools, and other features provided by us through our website.
                </p>
                <p className="text-gray-700">
                  "Website" refers to the EaseSure Insurance website, accessible at www.easesure.com.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">3. Eligibility</h2>
                <p className="text-gray-700 mb-3">
                  To use our Services, you must be at least 18 years old and have the legal capacity to enter into contracts.
                </p>
                <p className="text-gray-700">
                  You represent and warrant that all information you provide to us is accurate, complete, and up-to-date.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">4. Insurance Policies</h2>
                <p className="text-gray-700 mb-3">
                  Insurance policies are subject to the terms, conditions, limitations, exclusions, and eligibility requirements set forth in the policy documents. The policy documents include the policy certificate, schedule, endorsements, and any other documents issued by the insurance company.
                </p>
                <p className="text-gray-700 mb-3">
                  We are an insurance broker/aggregator that connects you with insurance providers. The actual insurance contract is between you and the insurance provider.
                </p>
                <p className="text-gray-700">
                  Premium rates for insurance policies are determined by the insurance provider and are subject to change.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">5. Accuracy of Information</h2>
                <p className="text-gray-700 mb-3">
                  We make every effort to provide accurate information on our Website. However, we do not guarantee the accuracy, completeness, or reliability of any information on our Website.
                </p>
                <p className="text-gray-700 mb-3">
                  The information provided on our Website is for general guidance only and should not be considered as professional advice. You should consult with a qualified professional before making any financial or insurance decisions.
                </p>
                <p className="text-gray-700">
                  We reserve the right to modify the information on our Website at any time without prior notice.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">6. User Accounts</h2>
                <p className="text-gray-700 mb-3">
                  You may need to create an account to access certain features of our Services. You are responsible for maintaining the confidentiality of your account credentials.
                </p>
                <p className="text-gray-700 mb-3">
                  You are solely responsible for all activities that occur under your account.
                </p>
                <p className="text-gray-700">
                  We reserve the right to terminate or suspend your account at any time for any reason without prior notice.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">7. Prohibited Conduct</h2>
                <p className="text-gray-700 mb-3">
                  You agree not to use our Website or Services for any unlawful purpose or in any way that could damage, disable, overburden, or impair our Website or interfere with any other party's use of our Website.
                </p>
                <p className="text-gray-700 mb-3">
                  You agree not to attempt to gain unauthorized access to any part of our Website, other accounts, computer systems, or networks connected to our Website.
                </p>
                <p className="text-gray-700 mb-3">
                  You agree not to use any automated means, including but not limited to, robots, spiders, or scrapers, to access our Website or collect any information from our Website.
                </p>
                <p className="text-gray-700">
                  You agree not to provide false or misleading information when using our Website or Services.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">8. Intellectual Property</h2>
                <p className="text-gray-700 mb-3">
                  All content on our Website, including but not limited to text, graphics, logos, icons, images, audio clips, digital downloads, data compilations, and software, is the property of EaseSure Insurance or its content suppliers and is protected by copyright laws.
                </p>
                <p className="text-gray-700 mb-3">
                  You are granted a limited, non-exclusive, non-transferable license to access and use our Website for personal, non-commercial purposes.
                </p>
                <p className="text-gray-700">
                  You may not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any content on our Website without our prior written consent.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">9. Privacy Policy</h2>
                <p className="text-gray-700 mb-3">
                  Your use of our Website and Services is also governed by our Privacy Policy, which is incorporated by reference into these Terms.
                </p>
                <p className="text-gray-700">
                  Please review our Privacy Policy carefully to understand our practices regarding your personal information.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">10. Limitation of Liability</h2>
                <p className="text-gray-700 mb-3">
                  To the fullest extent permitted by law, EaseSure Insurance shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising out of or related to your use of our Website or Services.
                </p>
                <p className="text-gray-700">
                  Our total liability to you for all claims arising out of or related to your use of our Website or Services shall not exceed the amount you paid for the specific Service giving rise to the claim.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">11. Indemnification</h2>
                <p className="text-gray-700">
                  You agree to indemnify, defend, and hold harmless EaseSure Insurance and its officers, directors, employees, agents, successors, and assigns from and against any and all claims, liabilities, damages, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising from or relating to your violation of these Terms or your use of our Website or Services.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">12. Changes to Terms</h2>
                <p className="text-gray-700 mb-3">
                  We reserve the right to modify these Terms at any time without prior notice. The updated Terms will be posted on our Website with the updated effective date.
                </p>
                <p className="text-gray-700">
                  Your continued use of our Website or Services after the posting of updated Terms constitutes your acceptance of the updated Terms.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">13. Governing Law</h2>
                <p className="text-gray-700">
                  These Terms are governed by and construed in accordance with the laws of India, without regard to its conflict of law principles.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">14. Contact Us</h2>
                <p className="text-gray-700">
                  If you have any questions or concerns about these Terms, please contact us at legal@easesure.com or call us at 1800-266-0101.
                </p>
              </div>
              
              <div>
                <p className="text-gray-700 italic">
                  Last updated: May 5, 2025
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Terms;
