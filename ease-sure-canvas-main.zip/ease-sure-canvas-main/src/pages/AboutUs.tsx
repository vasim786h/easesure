
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Shield, Award, Users, TrendingUp } from "lucide-react";

const AboutUs = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-r from-easesure-primary to-easesure-secondary text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">About EaseSure</h1>
              <p className="text-xl opacity-90">
                Your trusted partner in navigating the complex world of insurance
              </p>
            </div>
          </div>
        </section>
        
        {/* Our Story Section */}
        <section className="py-16">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-semibold mb-6">Our Story</h2>
                <p className="text-gray-600 mb-4">
                  Founded in 2015, EaseSure was born from a simple idea: insurance shouldn't be complicated. Our founders, experienced insurance professionals, saw firsthand how confusing insurance could be for everyday people.
                </p>
                <p className="text-gray-600 mb-4">
                  They envisioned a company that would make insurance accessible, affordable, and easy to understand. Today, EaseSure serves over 3 million customers across India, helping them navigate the complex world of insurance with confidence.
                </p>
                <p className="text-gray-600">
                  Our mission is to protect what matters most to you while providing exceptional value and service. We believe that everyone deserves access to quality insurance coverage without the confusion and complexity.
                </p>
              </div>
              <div className="bg-easesure-accent rounded-xl p-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-easesure-primary mb-2">3M+</div>
                    <p className="text-gray-600">Happy Customers</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-easesure-primary mb-2">40+</div>
                    <p className="text-gray-600">Insurance Partners</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-easesure-primary mb-2">₹500Cr+</div>
                    <p className="text-gray-600">Claims Settled</p>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-easesure-primary mb-2">97%</div>
                    <p className="text-gray-600">Satisfaction Rate</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Core Values Section */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-semibold mb-4">Our Core Values</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                These principles guide everything we do at EaseSure
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="bg-easesure-primary/10 w-14 h-14 flex items-center justify-center rounded-full mb-4">
                  <Shield className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Trust</h3>
                <p className="text-gray-600">
                  We build lasting relationships with our customers based on honesty, integrity, and transparency.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="bg-easesure-primary/10 w-14 h-14 flex items-center justify-center rounded-full mb-4">
                  <Award className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Excellence</h3>
                <p className="text-gray-600">
                  We are committed to providing exceptional service and constantly striving to exceed expectations.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="bg-easesure-primary/10 w-14 h-14 flex items-center justify-center rounded-full mb-4">
                  <Users className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Empathy</h3>
                <p className="text-gray-600">
                  We understand our customers' needs and concerns, and we're committed to addressing them with care.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="bg-easesure-primary/10 w-14 h-14 flex items-center justify-center rounded-full mb-4">
                  <TrendingUp className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Innovation</h3>
                <p className="text-gray-600">
                  We continuously evolve our products and services to meet the changing needs of our customers.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Team Section */}
        <section className="py-16">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-semibold mb-4">Our Leadership Team</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Meet the experienced professionals who guide our company
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((index) => (
                <div key={index} className="text-center">
                  <div className="bg-gray-100 w-40 h-40 rounded-full mx-auto mb-4"></div>
                  <h3 className="text-xl font-semibold mb-1">John Doe</h3>
                  <p className="text-easesure-primary mb-3">Chief Executive Officer</p>
                  <p className="text-gray-600">
                    Over 15 years of experience in insurance and financial services.
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutUs;
