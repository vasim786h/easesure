
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { MapPin, Plane, ShieldCheck } from "lucide-react";

const Travel = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-easesure-primary to-easesure-secondary py-20 text-white">
          <div className="container">
            <div className="max-w-2xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Travel With Peace of Mind</h1>
              <p className="text-xl mb-8">
                Comprehensive travel insurance for worry-free journeys around the globe.
              </p>
              <Button size="lg" className="bg-white text-easesure-primary hover:bg-gray-100">
                Get a Quote
              </Button>
            </div>
          </div>
        </section>
        
        {/* Plans Section */}
        <section className="py-16 bg-white">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Our Travel Insurance Plans</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <MapPin className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Domestic Travel</h3>
                <p className="text-gray-600 mb-4">
                  Coverage for trips within your home country.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Trip cancellation</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Baggage loss</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Medical emergencies</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Learn More</Button>
              </div>
              
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow relative">
                <div className="absolute -top-3 -right-3 bg-easesure-secondary text-white px-3 py-1 rounded-full text-sm font-medium">
                  Popular
                </div>
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <Plane className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">International Travel</h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive coverage for your international journeys.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Medical expenses abroad</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Emergency evacuation</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>24/7 travel assistance</span>
                  </li>
                </ul>
                <Button className="w-full">Learn More</Button>
              </div>
              
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <ShieldCheck className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Multi-Trip Annual</h3>
                <p className="text-gray-600 mb-4">
                  Year-round coverage for frequent travelers.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Unlimited trips within a year</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Cost-effective for frequent travelers</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Comprehensive coverage</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Learn More</Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl font-bold mb-4">Ready for your next adventure?</h2>
              <p className="text-xl mb-6 max-w-2xl mx-auto">
                Get travel insurance that covers you anywhere in the world.
              </p>
              <Button className="bg-white text-easesure-primary hover:bg-gray-100 transition-colors text-lg px-8 py-6">
                Get Started Now
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Travel;
