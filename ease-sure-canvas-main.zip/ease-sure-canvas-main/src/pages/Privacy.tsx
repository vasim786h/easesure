
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const Privacy = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-8">Privacy Policy</h1>
            <div className="bg-white rounded-xl shadow-sm p-8 space-y-8">
              <div>
                <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
                <p className="text-gray-700 mb-3">
                  At EaseSure Insurance, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
                </p>
                <p className="text-gray-700">
                  Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access our website or use our services.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">2. Information We Collect</h2>
                <p className="text-gray-700 mb-3">
                  We collect several types of information from and about users of our website and services, including:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>
                    <strong>Personal Information:</strong> This includes your name, address, email address, phone number, date of birth, gender, and other personally identifiable information that you provide to us.
                  </li>
                  <li>
                    <strong>Financial Information:</strong> This includes payment details such as credit card or bank account information when you purchase an insurance policy through our platform.
                  </li>
                  <li>
                    <strong>Insurance Information:</strong> This includes information related to your insurance policies, claims history, and risk profile.
                  </li>
                  <li>
                    <strong>Device and Usage Information:</strong> This includes information about your device, browser, IP address, and how you interact with our website.
                  </li>
                </ul>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">3. How We Collect Information</h2>
                <p className="text-gray-700 mb-3">
                  We collect information from you when you:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Register on our website or create an account</li>
                  <li>Fill out forms or submit information on our website</li>
                  <li>Request a quote or purchase an insurance policy</li>
                  <li>File a claim or make a customer service request</li>
                  <li>Subscribe to our newsletter or respond to a survey</li>
                  <li>Browse our website or use our mobile applications</li>
                </ul>
                <p className="text-gray-700 mt-3">
                  We may also collect information from third parties, such as insurance providers, credit bureaus, and other financial institutions, to verify your identity and assess your insurance risk.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">4. How We Use Your Information</h2>
                <p className="text-gray-700 mb-3">
                  We use the information we collect to:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>Provide and improve our website and services</li>
                  <li>Process your insurance applications, quotes, and claims</li>
                  <li>Communicate with you about your account and insurance policies</li>
                  <li>Send you marketing communications (subject to your communication preferences)</li>
                  <li>Conduct research and analysis to improve our products and services</li>
                  <li>Comply with legal obligations and enforce our policies</li>
                  <li>Detect, prevent, and address fraud, security breaches, and technical issues</li>
                </ul>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">5. Information Sharing and Disclosure</h2>
                <p className="text-gray-700 mb-3">
                  We may share your information with:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>
                    <strong>Insurance Providers:</strong> To provide you with insurance quotes and policies, we may share your information with insurance companies and underwriters.
                  </li>
                  <li>
                    <strong>Service Providers:</strong> We may share your information with third-party service providers who perform services on our behalf, such as payment processing, data analysis, email delivery, and customer service.
                  </li>
                  <li>
                    <strong>Business Partners:</strong> We may share your information with our business partners to offer you certain products or services.
                  </li>
                  <li>
                    <strong>Legal Authorities:</strong> We may disclose your information if required to do so by law or in response to valid requests by public authorities.
                  </li>
                  <li>
                    <strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of that transaction.
                  </li>
                </ul>
                <p className="text-gray-700 mt-3">
                  We do not sell, rent, or lease your personal information to third parties without your explicit consent.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">6. Data Security</h2>
                <p className="text-gray-700 mb-3">
                  We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
                </p>
                <p className="text-gray-700 mb-3">
                  However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to protect your personal information, we cannot guarantee its absolute security.
                </p>
                <p className="text-gray-700">
                  It is your responsibility to keep your account credentials confidential and to notify us immediately if you believe your account has been compromised.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">7. Cookies and Tracking Technologies</h2>
                <p className="text-gray-700 mb-3">
                  We use cookies and similar tracking technologies to track the activity on our website and hold certain information to improve your experience.
                </p>
                <p className="text-gray-700 mb-3">
                  Cookies are files with a small amount of data that may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device.
                </p>
                <p className="text-gray-700">
                  You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, some portions of our website may not function properly.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">8. Your Rights and Choices</h2>
                <p className="text-gray-700 mb-3">
                  Depending on your location, you may have certain rights regarding your personal information, including:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-gray-700">
                  <li>The right to access your personal information</li>
                  <li>The right to correct inaccurate or incomplete information</li>
                  <li>The right to delete your personal information</li>
                  <li>The right to restrict or object to the processing of your personal information</li>
                  <li>The right to data portability</li>
                  <li>The right to withdraw consent at any time</li>
                </ul>
                <p className="text-gray-700 mt-3">
                  To exercise these rights, please contact us using the contact information provided below.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">9. Marketing Communications</h2>
                <p className="text-gray-700 mb-3">
                  You may opt-out of receiving marketing communications from us by clicking on the unsubscribe link in our emails or by contacting us directly.
                </p>
                <p className="text-gray-700">
                  Even if you opt-out of marketing communications, we may still send you non-promotional communications, such as those about your account or our ongoing business relations.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">10. Children's Privacy</h2>
                <p className="text-gray-700">
                  Our website and services are not intended for individuals under the age of 18. We do not knowingly collect personal information from children. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us immediately.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">11. Third-Party Links</h2>
                <p className="text-gray-700">
                  Our website may contain links to third-party websites or services that are not owned or controlled by EaseSure Insurance. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party websites or services.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">12. Changes to this Privacy Policy</h2>
                <p className="text-gray-700">
                  We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date at the bottom of this page. You are advised to review this Privacy Policy periodically for any changes.
                </p>
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">13. Contact Us</h2>
                <p className="text-gray-700">
                  If you have any questions about this Privacy Policy or our privacy practices, please contact us at:
                </p>
                <p className="mt-2 text-gray-700">
                  Email: privacy@easesure.com<br />
                  Phone: 1800-266-0101<br />
                  Address: EaseSure Insurance, 123 Financial District, Bandra Kurla Complex, Mumbai, Maharashtra 400051, India
                </p>
              </div>
              
              <div>
                <p className="text-gray-700 italic">
                  Last updated: May 5, 2025
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Privacy;
