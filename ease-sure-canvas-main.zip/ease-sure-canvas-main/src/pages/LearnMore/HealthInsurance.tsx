
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Heart, CheckCircle, Clock, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";

const HealthInsurance = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-easesure-primary to-easesure-secondary py-20 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="h-8 w-8" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Health Insurance</h1>
              <p className="text-xl mb-8">
                Comprehensive coverage for you and your family with access to the best healthcare facilities.
              </p>
              <Link to="/get-insurance">
                <Button size="lg" className="bg-white text-easesure-primary hover:bg-gray-100">
                  Get a Quote
                </Button>
              </Link>
            </div>
          </div>
        </section>
        
        {/* Features */}
        <section className="py-16 bg-white">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Key Benefits</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <div className="text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Extensive Coverage</h3>
                <p className="text-gray-600">
                  Access to over 10,000+ cashless hospitals and comprehensive coverage for pre and post hospitalization.
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Quick Claims</h3>
                <p className="text-gray-600">
                  Hassle-free claim settlement with 95% of claims processed within 24 hours.
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-8 w-8 text-easesure-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Cost Effective</h3>
                <p className="text-gray-600">
                  Save up to 45% on premiums compared to other providers with our special discounts.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Plans */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Our Health Insurance Plans</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm p-8 border-t-4 border-easesure-primary">
                <h3 className="text-xl font-semibold mb-4">Basic Plan</h3>
                <p className="text-3xl font-bold mb-6">₹5,000<span className="text-sm font-normal text-gray-500">/year</span></p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>₹5 Lakhs coverage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Cashless treatment at 5,000+ hospitals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Room rent capping applicable</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Choose Plan</Button>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-8 border-t-4 border-easesure-secondary relative transform scale-105">
                <div className="absolute top-0 right-0 bg-easesure-secondary text-white px-3 py-1 text-sm">Popular</div>
                <h3 className="text-xl font-semibold mb-4">Premium Plan</h3>
                <p className="text-3xl font-bold mb-6">₹12,000<span className="text-sm font-normal text-gray-500">/year</span></p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>₹20 Lakhs coverage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Cashless treatment at 8,000+ hospitals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>No room rent capping</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Maternity cover included</span>
                  </li>
                </ul>
                <Button className="w-full bg-easesure-primary">Choose Plan</Button>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-8 border-t-4 border-easesure-primary">
                <h3 className="text-xl font-semibold mb-4">Family Plan</h3>
                <p className="text-3xl font-bold mb-6">₹20,000<span className="text-sm font-normal text-gray-500">/year</span></p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>₹50 Lakhs coverage</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Covers spouse and up to 3 children</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Cashless treatment at 10,000+ hospitals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                    <span>Annual health check-up for all members</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Choose Plan</Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-white">
          <div className="container">
            <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl font-bold mb-4">Ready to secure your health?</h2>
              <p className="text-xl mb-6 max-w-2xl mx-auto">
                Get personalized health insurance quotes and enjoy peace of mind knowing you're covered
              </p>
              <Link to="/get-insurance">
                <Button className="bg-white text-easesure-primary hover:bg-gray-100 transition-colors text-lg px-8 py-6">
                  Get Started Now
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default HealthInsurance;
