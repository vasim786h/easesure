import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { toast } from "sonner";
import { Car, Heart, Shield, Plane, Briefcase, Home, Upload, ArrowRight } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";

const MAX_FILE_SIZE = 5000000; // 5MB
const ACCEPTED_FILE_TYPES = ["application/pdf", "image/jpeg", "image/png"];

const quoteFormSchema = z.object({
  firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Phone number must be at least 10 digits." }),
  dob: z.string().min(1, { message: "Date of birth is required." }),
  gender: z.enum(["male", "female", "other"], { required_error: "Please select your gender." }),
  address: z.string().min(5, { message: "Address must be at least 5 characters." }),
  city: z.string().min(2, { message: "City is required." }),
  state: z.string().min(2, { message: "State is required." }),
  pincode: z.string().min(6, { message: "Please enter a valid pincode." }),
  additionalInfo: z.string().optional(),
  contactPreference: z.enum(["email", "phone", "whatsapp"], { required_error: "Please select your preferred contact method." }),
  termsAccepted: z.boolean().refine((val) => val === true, {
    message: "You must accept the terms and conditions.",
  }),
}).partial(); // Make all fields partial since they'll be conditionally required based on insurance type

type QuoteFormValues = z.infer<typeof quoteFormSchema>;

const GetInsurance = () => {
  const [selectedInsurance, setSelectedInsurance] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);

  const form = useForm<QuoteFormValues>({
    resolver: zodResolver(quoteFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      additionalInfo: "",
      termsAccepted: false,
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      const validFiles = selectedFiles.filter(file => 
        file.size <= MAX_FILE_SIZE && ACCEPTED_FILE_TYPES.includes(file.type)
      );
      
      if (validFiles.length !== selectedFiles.length) {
        toast.error("Some files were rejected. Please ensure files are PDFs or images under 5MB.");
      }
      
      setFiles(prev => [...prev, ...validFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const nextStep = () => {
    if (currentStep === 1 && !selectedInsurance) {
      toast.error("Please select an insurance type to continue.");
      return;
    }
    
    const formValid = form.trigger();
    if (formValid) {
      setCurrentStep(prevStep => prevStep + 1);
    }
  };

  const prevStep = () => {
    setCurrentStep(prevStep => prevStep - 1);
  };

  const onSubmit = (data: QuoteFormValues) => {
    console.log({ ...data, insuranceType: selectedInsurance, files });
    toast.success("Your insurance quote request has been submitted! Our team will contact you shortly.");
  };

  const insuranceTypes = [
    { id: "health", name: "Health Insurance", icon: <Heart className="h-5 w-5" /> },
    { id: "life", name: "Life Insurance", icon: <Shield className="h-5 w-5" /> },
    { id: "motor", name: "Motor Insurance", icon: <Car className="h-5 w-5" /> },
    { id: "travel", name: "Travel Insurance", icon: <Plane className="h-5 w-5" /> },
    { id: "business", name: "Business Insurance", icon: <Briefcase className="h-5 w-5" /> },
    { id: "home", name: "Home Insurance", icon: <Home className="h-5 w-5" /> }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12 bg-gray-50">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary p-6 md:p-8 text-white">
                <h1 className="text-2xl md:text-3xl font-bold mb-2">Get Insurance Quote</h1>
                <p className="opacity-90">Fill out the form below to receive a personalized insurance quote</p>
              </div>
              
              {/* Progress Steps */}
              <div className="px-6 md:px-8 pt-6">
                <div className="flex justify-between mb-8">
                  {["Select Insurance", "Personal Details", "Additional Info", "Review & Submit"].map((step, index) => (
                    <div key={index} className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${
                        currentStep > index + 1 
                          ? "bg-easesure-primary text-white" 
                          : currentStep === index + 1 
                          ? "bg-easesure-primary text-white" 
                          : "bg-gray-200 text-gray-500"
                      }`}>
                        {currentStep > index + 1 ? "✓" : index + 1}
                      </div>
                      <span className={`text-xs md:text-sm ${currentStep === index + 1 ? "text-easesure-primary font-medium" : "text-gray-500"}`}>
                        {step}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 md:p-8">
                  {/* Step 1: Select Insurance */}
                  {currentStep === 1 && (
                    <div>
                      <h2 className="text-xl font-semibold mb-6">Select Insurance Type</h2>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                        {insuranceTypes.map((type) => (
                          <button
                            key={type.id}
                            type="button"
                            className={`flex items-center p-4 border rounded-lg transition-colors ${
                              selectedInsurance === type.id
                                ? "bg-easesure-primary text-white border-easesure-primary"
                                : "bg-white hover:bg-gray-50 border-gray-200"
                            }`}
                            onClick={() => setSelectedInsurance(type.id)}
                          >
                            <span className={`rounded-full p-2 mr-3 ${
                              selectedInsurance === type.id ? "bg-white/20" : "bg-easesure-primary/10"
                            }`}>
                              {type.icon}
                            </span>
                            <span>{type.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Step 2: Personal Details */}
                  {currentStep === 2 && (
                    <div>
                      <h2 className="text-xl font-semibold mb-6">Personal Details</h2>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Last Name</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="dob"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date of Birth</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="gender"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>Gender</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="male" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">Male</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="female" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">Female</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="other" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">Other</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  )}
                  
                  {/* Step 3: Additional Info */}
                  {currentStep === 3 && (
                    <div>
                      <h2 className="text-xl font-semibold mb-6">Additional Information</h2>
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="address"
                            render={({ field }) => (
                              <FormItem className="sm:col-span-2">
                                <FormLabel>Address</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="city"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>City</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="state"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>State</FormLabel>
                                <FormControl>
                                  <Select 
                                    onValueChange={field.onChange} 
                                    defaultValue={field.value}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select state" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="maharashtra">Maharashtra</SelectItem>
                                      <SelectItem value="delhi">Delhi</SelectItem>
                                      <SelectItem value="karnataka">Karnataka</SelectItem>
                                      <SelectItem value="tamilnadu">Tamil Nadu</SelectItem>
                                      <SelectItem value="telangana">Telangana</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="pincode"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Pincode</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {/* File Upload */}
                        <div className="space-y-2">
                          <Label>Upload Documents (PDF, JPEG, PNG - Max 5MB)</Label>
                          <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
                            <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                            <p className="text-sm text-gray-500 mb-2">Drag and drop your files here, or click to browse</p>
                            <Input 
                              type="file" 
                              multiple
                              accept=".pdf,.jpg,.jpeg,.png"
                              onChange={handleFileChange}
                              className="hidden"
                              id="file-upload"
                            />
                            <Label htmlFor="file-upload">
                              <Button 
                                type="button" 
                                variant="outline"
                                className="text-easesure-primary border-easesure-primary"
                              >
                                Browse Files
                              </Button>
                            </Label>
                          </div>
                          
                          {/* File List */}
                          {files.length > 0 && (
                            <div className="mt-4">
                              <h4 className="font-medium text-sm mb-2">Uploaded Files:</h4>
                              <ul className="space-y-2">
                                {files.map((file, index) => (
                                  <li key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                                    <span className="text-sm truncate max-w-[80%]">{file.name}</span>
                                    <Button 
                                      type="button" 
                                      variant="ghost" 
                                      size="sm" 
                                      onClick={() => removeFile(index)}
                                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                    >
                                      Remove
                                    </Button>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="additionalInfo"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Additional Information (Optional)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Any specific requirements or questions..." 
                                  className="min-h-32" 
                                  {...field}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="contactPreference"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preferred Contact Method</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-4"
                                >
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="email" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">Email</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="phone" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">Phone</FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-2">
                                    <FormControl>
                                      <RadioGroupItem value="whatsapp" />
                                    </FormControl>
                                    <FormLabel className="cursor-pointer">WhatsApp</FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  )}
                  
                  {/* Step 4: Review & Submit */}
                  {currentStep === 4 && (
                    <div>
                      <h2 className="text-xl font-semibold mb-6">Review & Submit</h2>
                      <div className="space-y-6">
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h3 className="font-medium mb-3">Insurance Details</h3>
                          <p className="text-gray-700">
                            <span className="font-medium">Insurance Type:</span> {insuranceTypes.find(t => t.id === selectedInsurance)?.name}
                          </p>
                        </div>
                        
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h3 className="font-medium mb-3">Personal Information</h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-700">
                            <p><span className="font-medium">Name:</span> {form.getValues("firstName")} {form.getValues("lastName")}</p>
                            <p><span className="font-medium">Email:</span> {form.getValues("email")}</p>
                            <p><span className="font-medium">Phone:</span> {form.getValues("phone")}</p>
                            <p><span className="font-medium">Date of Birth:</span> {form.getValues("dob")}</p>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h3 className="font-medium mb-3">Address</h3>
                          <p className="text-gray-700">{form.getValues("address")}, {form.getValues("city")}, {form.getValues("state")}, {form.getValues("pincode")}</p>
                        </div>
                        
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h3 className="font-medium mb-3">Documents</h3>
                          {files.length > 0 ? (
                            <ul className="text-gray-700">
                              {files.map((file, index) => (
                                <li key={index}>{file.name}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-gray-500">No documents uploaded</p>
                          )}
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="termsAccepted"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel>
                                  I agree to the{" "}
                                  <Link to="/terms" className="text-easesure-primary hover:underline">
                                    Terms of Service
                                  </Link>{" "}
                                  and{" "}
                                  <Link to="/privacy" className="text-easesure-primary hover:underline">
                                    Privacy Policy
                                  </Link>
                                </FormLabel>
                                <FormMessage />
                              </div>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  )}
                  
                  {/* Navigation Buttons */}
                  <div className="flex justify-between mt-8">
                    {currentStep > 1 && (
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={prevStep}
                      >
                        Back
                      </Button>
                    )}
                    
                    {currentStep < 4 ? (
                      <Button 
                        type="button" 
                        className="ml-auto bg-easesure-primary hover:bg-easesure-secondary"
                        onClick={nextStep}
                      >
                        Next <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button 
                        type="submit" 
                        className="ml-auto bg-easesure-primary hover:bg-easesure-secondary"
                      >
                        Submit Quote Request
                      </Button>
                    )}
                  </div>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default GetInsurance;
