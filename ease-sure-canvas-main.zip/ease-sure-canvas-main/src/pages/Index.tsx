
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/home/HeroSection";
import InsuranceTypes from "@/components/home/InsuranceTypes";
import WhyChooseUs from "@/components/home/WhyChooseUs";
import TestimonialsSection from "@/components/home/TestimonialsSection";
import { Button } from "@/components/ui/button";
import { Shield, BarChart, Award } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <HeroSection />
        <InsuranceTypes />
        
        {/* Partners Section */}
        <section className="py-12 bg-white">
          <div className="container">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold text-gray-700">Trusted by 40+ Insurance Partners</h2>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6">
              {/* Partner logos would normally be images from actual partners */}
              {[1, 2, 3, 4, 5, 6].map((index) => (
                <div key={index} className="h-12 bg-gray-100 rounded-md px-6 flex items-center justify-center">
                  <span className="text-gray-500 font-medium">Partner {index}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        <WhyChooseUs />
        
        {/* Stats Section */}
        <section className="py-16 bg-easesure-primary text-white">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="flex items-center justify-center mb-3">
                  <Shield className="h-10 w-10" />
                </div>
                <h3 className="text-4xl font-bold mb-2">3M+</h3>
                <p className="text-lg opacity-80">Happy Customers</p>
              </div>
              <div>
                <div className="flex items-center justify-center mb-3">
                  <BarChart className="h-10 w-10" />
                </div>
                <h3 className="text-4xl font-bold mb-2">₹500Cr+</h3>
                <p className="text-lg opacity-80">Claims Settled</p>
              </div>
              <div>
                <div className="flex items-center justify-center mb-3">
                  <Award className="h-10 w-10" />
                </div>
                <h3 className="text-4xl font-bold mb-2">97%</h3>
                <p className="text-lg opacity-80">Customer Satisfaction</p>
              </div>
            </div>
          </div>
        </section>
        
        <TestimonialsSection />
        
        {/* CTA Section */}
        <section className="py-16 bg-white">
          <div className="container">
            <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to find the perfect insurance plan?</h2>
              <p className="text-xl mb-6 max-w-2xl mx-auto">
                Get personalized quotes from top insurers and save time and money on your insurance
              </p>
              <Button className="bg-white text-easesure-primary hover:bg-gray-100 transition-colors text-lg px-8 py-6">
                Get Started Now
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
