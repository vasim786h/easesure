
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Car, Shield, Wrench } from "lucide-react";

const Motor = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-easesure-primary to-easesure-secondary py-20 text-white">
          <div className="container">
            <div className="max-w-2xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Drive With Confidence</h1>
              <p className="text-xl mb-8">
                Comprehensive motor insurance solutions to keep you protected on the road.
              </p>
              <Button size="lg" className="bg-white text-easesure-primary hover:bg-gray-100">
                Get a Quote
              </Button>
            </div>
          </div>
        </section>
        
        {/* Plans Section */}
        <section className="py-16 bg-white">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Our Motor Insurance Plans</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <Shield className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Third Party</h3>
                <p className="text-gray-600 mb-4">
                  Basic coverage that meets legal requirements for your vehicle.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Legal liability coverage</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Personal accident cover</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Most affordable option</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Learn More</Button>
              </div>
              
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow relative">
                <div className="absolute -top-3 -right-3 bg-easesure-secondary text-white px-3 py-1 rounded-full text-sm font-medium">
                  Popular
                </div>
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <Car className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Comprehensive</h3>
                <p className="text-gray-600 mb-4">
                  Complete protection for your vehicle against damages and theft.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Own damage coverage</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Third-party liability</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Natural disaster coverage</span>
                  </li>
                </ul>
                <Button className="w-full">Learn More</Button>
              </div>
              
              <div className="border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-center mb-4 w-12 h-12 rounded-full bg-easesure-primary/10 text-easesure-primary">
                  <Wrench className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Add-Ons</h3>
                <p className="text-gray-600 mb-4">
                  Additional coverage options to enhance your motor insurance.
                </p>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Zero depreciation</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Roadside assistance</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-easesure-primary mr-2">•</span> 
                    <span>Engine protection</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Learn More</Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl font-bold mb-4">Drive worry-free with EaseSure</h2>
              <p className="text-xl mb-6 max-w-2xl mx-auto">
                Get your motor insurance quote today and experience hassle-free claims.
              </p>
              <Button className="bg-white text-easesure-primary hover:bg-gray-100 transition-colors text-lg px-8 py-6">
                Get Started Now
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Motor;
