
import React from "react";
import { Search, Filter, MoreHorizontal, ShieldCheck } from "lucide-react";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AdminInsurance = () => {
  // Sample insurance policies data
  const policies = [
    { id: 1, policyNumber: "POL-1234", type: "Health", customer: "John Doe", status: "Active", startDate: "2023-01-15", endDate: "2024-01-14", premium: "$1,200" },
    { id: 2, policyNumber: "POL-2345", type: "Life", customer: "Jane Smith", status: "Active", startDate: "2023-02-20", endDate: "2043-02-19", premium: "$850" },
    { id: 3, policyNumber: "POL-3456", type: "Motor", customer: "Robert Johnson", status: "Active", startDate: "2023-03-05", endDate: "2024-03-04", premium: "$650" },
    { id: 4, policyNumber: "POL-4567", type: "Travel", customer: "Lisa Brown", status: "Expired", startDate: "2023-01-25", endDate: "2023-07-24", premium: "$250" },
    { id: 5, policyNumber: "POL-5678", type: "Business", customer: "Michael Wilson", status: "Active", startDate: "2022-12-10", endDate: "2023-12-09", premium: "$2,500" },
    { id: 6, policyNumber: "POL-6789", type: "Health", customer: "Emily Davis", status: "Active", startDate: "2023-04-15", endDate: "2024-04-14", premium: "$950" },
  ];

  // Sample claims data
  const claims = [
    { id: 1, claimNumber: "CLM-1234", policyNumber: "POL-1234", customer: "John Doe", type: "Health", amount: "$500", status: "Approved", date: "2023-05-15" },
    { id: 2, claimNumber: "CLM-2345", policyNumber: "POL-3456", customer: "Robert Johnson", type: "Motor", amount: "$1,200", status: "Pending", date: "2023-06-20" },
    { id: 3, claimNumber: "CLM-3456", policyNumber: "POL-6789", customer: "Emily Davis", type: "Health", amount: "$350", status: "Approved", date: "2023-07-05" },
    { id: 4, claimNumber: "CLM-4567", policyNumber: "POL-5678", customer: "Michael Wilson", type: "Business", amount: "$4,500", status: "Under Review", date: "2023-07-25" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Insurance Management</h1>
        <Button>Create New Policy</Button>
      </div>

      <Tabs defaultValue="policies">
        <TabsList>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="claims">Claims</TabsTrigger>
        </TabsList>
        
        <TabsContent value="policies" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>All Policies</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="relative w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    type="search"
                    placeholder="Search policies..."
                    className="pl-9"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Policy Number</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Start Date</TableHead>
                      <TableHead>End Date</TableHead>
                      <TableHead>Premium</TableHead>
                      <TableHead className="w-12"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {policies.map((policy) => (
                      <TableRow key={policy.id}>
                        <TableCell>{policy.policyNumber}</TableCell>
                        <TableCell className="flex items-center gap-2">
                          <div className="bg-gray-100 rounded-full p-1">
                            <ShieldCheck className="h-4 w-4" />
                          </div>
                          {policy.type}
                        </TableCell>
                        <TableCell>{policy.customer}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                            policy.status === "Active" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                          }`}>
                            {policy.status}
                          </span>
                        </TableCell>
                        <TableCell>{policy.startDate}</TableCell>
                        <TableCell>{policy.endDate}</TableCell>
                        <TableCell>{policy.premium}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="flex items-center justify-between mt-4">
                <p className="text-sm text-gray-500">
                  Showing 1-6 of 6 policies
                </p>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    Next
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="claims" className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>All Claims</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="relative w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    type="search"
                    placeholder="Search claims..."
                    className="pl-9"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Claim Number</TableHead>
                      <TableHead>Policy Number</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="w-12"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {claims.map((claim) => (
                      <TableRow key={claim.id}>
                        <TableCell>{claim.claimNumber}</TableCell>
                        <TableCell>{claim.policyNumber}</TableCell>
                        <TableCell>{claim.customer}</TableCell>
                        <TableCell>{claim.type}</TableCell>
                        <TableCell>{claim.amount}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                            claim.status === "Approved" ? "bg-green-50 text-green-700" : 
                            claim.status === "Pending" ? "bg-yellow-50 text-yellow-700" : 
                            "bg-blue-50 text-blue-700"
                          }`}>
                            {claim.status}
                          </span>
                        </TableCell>
                        <TableCell>{claim.date}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="flex items-center justify-between mt-4">
                <p className="text-sm text-gray-500">
                  Showing 1-4 of 4 claims
                </p>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    Next
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminInsurance;
