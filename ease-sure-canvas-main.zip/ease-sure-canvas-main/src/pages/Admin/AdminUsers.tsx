
import React from "react";
import { User, MoreHorizontal, Search, Filter } from "lucide-react";
import { 
  Table, 
  TableHeader, 
  TableBody, 
  TableHead, 
  TableRow, 
  TableCell 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

const AdminUsers = () => {
  // Sample user data
  const users = [
    { id: 1, name: "John Doe", email: "john@example.com", role: "Customer", status: "Active", dateJoined: "2023-01-15" },
    { id: 2, name: "Jane Smith", email: "jane@example.com", role: "Customer", status: "Active", dateJoined: "2023-02-20" },
    { id: 3, name: "Robert Johnson", email: "robert@example.com", role: "Agent", status: "Active", dateJoined: "2023-03-05" },
    { id: 4, name: "Lisa Brown", email: "lisa@example.com", role: "Customer", status: "Inactive", dateJoined: "2023-01-25" },
    { id: 5, name: "Michael Wilson", email: "michael@example.com", role: "Admin", status: "Active", dateJoined: "2022-12-10" },
    { id: 6, name: "Emily Davis", email: "emily@example.com", role: "Customer", status: "Active", dateJoined: "2023-04-15" },
    { id: 7, name: "David Miller", email: "david@example.com", role: "Agent", status: "Active", dateJoined: "2023-02-28" },
    { id: 8, name: "Sarah Wilson", email: "sarah@example.com", role: "Customer", status: "Inactive", dateJoined: "2023-03-20" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Users</h1>
        <Button>Add New User</Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>All Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search users..."
                className="pl-9"
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox />
                  </TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date Joined</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <Checkbox />
                    </TableCell>
                    <TableCell className="flex items-center gap-2">
                      <div className="bg-gray-100 rounded-full p-1">
                        <User className="h-5 w-5" />
                      </div>
                      {user.name}
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.role}</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                        user.status === "Active" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                      }`}>
                        {user.status}
                      </span>
                    </TableCell>
                    <TableCell>{user.dateJoined}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-gray-500">
              Showing 1-8 of 8 users
            </p>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminUsers;
