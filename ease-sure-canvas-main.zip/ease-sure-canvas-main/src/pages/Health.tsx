
import { Button } from "@/components/ui/button";
import Footer from "@/components/layout/Footer";
import Navbar from "@/components/layout/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Shield, Stethoscope, Hospital, Users, BadgeCheck } from "lucide-react";

const Health = () => {
  // Insurance plans
  const plans = [
    {
      title: "Basic Health Cover",
      price: "₹5,999",
      period: "per year",
      features: [
        "₹3 Lakhs coverage",
        "Cashless treatment at 5,000+ hospitals",
        "Room rent capping",
        "No pre-policy medical check-up",
        "Tax benefits under Sec 80D"
      ],
      recommended: false
    },
    {
      title: "Family Floater",
      price: "₹15,999",
      period: "per year",
      features: [
        "₹10 Lakhs coverage for entire family",
        "Cashless treatment at 8,000+ hospitals",
        "No room rent capping",
        "Free health check-up annually",
        "Cover for pre-existing diseases after 2 years",
        "Tax benefits under Sec 80D"
      ],
      recommended: true
    },
    {
      title: "Premium Health",
      price: "₹25,999",
      period: "per year",
      features: [
        "₹25 Lakhs coverage",
        "Global coverage for emergency treatment",
        "No room rent capping",
        "Cover for pre-existing diseases after 1 year",
        "Alternative treatments coverage (Ayurveda, etc.)",
        "Restoration benefit - Coverage gets restored once per policy year",
        "Tax benefits under Sec 80D"
      ],
      recommended: false
    }
  ];

  // Benefits
  const benefits = [
    {
      icon: <Heart className="h-10 w-10 text-easesure-primary" />,
      title: "Comprehensive Coverage",
      description: "Our health plans cover hospitalization, surgeries, medication, and more."
    },
    {
      icon: <Hospital className="h-10 w-10 text-easesure-primary" />,
      title: "Cashless Hospitals",
      description: "Get treatment at 10,000+ network hospitals without paying upfront."
    },
    {
      icon: <Users className="h-10 w-10 text-easesure-primary" />,
      title: "Family Coverage",
      description: "Protect your entire family under a single policy with our family floater plans."
    },
    {
      icon: <Shield className="h-10 w-10 text-easesure-primary" />,
      title: "Pre-existing Conditions",
      description: "Coverage for pre-existing conditions after specified waiting periods."
    },
    {
      icon: <Stethoscope className="h-10 w-10 text-easesure-primary" />,
      title: "Preventive Care",
      description: "Annual health check-ups included to help detect issues early."
    },
    {
      icon: <BadgeCheck className="h-10 w-10 text-easesure-primary" />,
      title: "Tax Benefits",
      description: "Get tax benefits on premium payments under Section 80D."
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      {/* Hero section */}
      <section className="bg-gradient-to-b from-easesure-accent to-white py-16 md:py-24">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-6">
              Health Insurance That Cares For You
            </h1>
            <p className="text-lg md:text-xl text-gray-700 mb-8">
              Comprehensive health insurance plans that provide coverage for medical expenses, 
              including hospitalization, surgeries, and medications.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-easesure-primary hover:bg-easesure-secondary">
                Get a Quote
              </Button>
              <Button size="lg" variant="outline" className="border-easesure-primary text-easesure-primary hover:bg-easesure-primary hover:text-white">
                Compare Plans
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Insurance plans section */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Choose Your Health Plan</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We offer flexible health insurance plans designed to meet your specific needs and budget.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div 
                key={index} 
                className={`relative rounded-xl overflow-hidden border ${plan.recommended ? 'border-easesure-primary shadow-lg' : 'border-gray-200'}`}
              >
                {plan.recommended && (
                  <div className="absolute top-0 right-0 bg-easesure-primary text-white py-1 px-4 rounded-bl-lg text-sm font-medium">
                    Best Value
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-4">{plan.title}</h3>
                  <div className="mb-6">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-gray-500"> {plan.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <svg className="h-5 w-5 text-easesure-primary mr-2 mt-0.5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${plan.recommended ? 'bg-easesure-primary hover:bg-easesure-secondary' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}
                  >
                    Choose Plan
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits section */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Benefits of Our Health Insurance</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Discover the advantages of choosing EaseSure for your health insurance needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-gray-100">
                <CardContent className="pt-6">
                  <div className="mb-4">{benefit.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ section */}
      <section className="py-16 bg-white">
        <div className="container max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600">
              Got questions about our health insurance plans? We've got answers.
            </p>
          </div>

          <div className="space-y-6">
            {[
              {
                question: "What is covered under health insurance?",
                answer: "Our health insurance plans typically cover hospitalization expenses, pre and post-hospitalization expenses, daycare procedures, ambulance charges, and more depending on the plan you choose."
              },
              {
                question: "Is there a waiting period for pre-existing conditions?",
                answer: "Yes, most health insurance plans have a waiting period for pre-existing conditions, which can range from 1 to 4 years depending on the plan and condition."
              },
              {
                question: "How do I make a claim?",
                answer: "We offer both cashless claims at network hospitals and reimbursement claims. For cashless claims, simply present your EaseSure health card at a network hospital. For reimbursement, submit the required documents after payment."
              },
              {
                question: "Can I add family members to my policy later?",
                answer: "Yes, you can add new family members to your policy at the time of renewal. Newborns can be added after 90 days from birth."
              }
            ].map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Health;
