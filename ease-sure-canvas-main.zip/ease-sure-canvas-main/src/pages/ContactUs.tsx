
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Phone number must be at least 10 digits." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactUs = () => {
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  const onSubmit = (data: ContactFormValues) => {
    console.log(data);
    toast.success("Your message has been sent. We'll get back to you soon!");
    form.reset();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-r from-easesure-primary to-easesure-secondary text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
              <p className="text-xl opacity-90">
                We're here to assist you with any questions or concerns
              </p>
            </div>
          </div>
        </section>
        
        {/* Contact Information */}
        <section className="py-16">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="bg-white p-6 rounded-xl shadow-sm text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 mx-auto flex items-center justify-center rounded-full mb-4">
                  <Phone className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Call Us</h3>
                <p className="text-gray-600 mb-2">24/7 Customer Support</p>
                <p className="text-easesure-primary font-medium">1800-266-0101</p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 mx-auto flex items-center justify-center rounded-full mb-4">
                  <Mail className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Email Us</h3>
                <p className="text-gray-600 mb-2">Quick Response Team</p>
                <p className="text-easesure-primary font-medium">support@easesure.com</p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm text-center">
                <div className="bg-easesure-primary/10 w-16 h-16 mx-auto flex items-center justify-center rounded-full mb-4">
                  <Clock className="h-7 w-7 text-easesure-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Working Hours</h3>
                <p className="text-gray-600 mb-2">Monday to Saturday</p>
                <p className="text-easesure-primary font-medium">9:00 AM - 9:00 PM</p>
              </div>
            </div>
            
            {/* Map and Form */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h2 className="text-2xl font-semibold mb-6">Send Us a Message</h2>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="john@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="+91 9876543210" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Please let us know how we can help you..." 
                              className="min-h-32" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full md:w-auto bg-easesure-primary hover:bg-easesure-secondary"
                    >
                      Send Message
                    </Button>
                  </form>
                </Form>
              </div>
              
              {/* Map */}
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h2 className="text-2xl font-semibold mb-6">Our Location</h2>
                <div className="h-80 bg-gray-200 rounded-lg mb-4">
                  {/* This would be a map component in a real implementation */}
                  <div className="h-full flex items-center justify-center text-gray-500">
                    Map placeholder - would integrate Google Maps or similar
                  </div>
                </div>
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-easesure-primary mr-2 mt-0.5 flex-shrink-0" />
                  <p className="text-gray-700">
                    EaseSure Insurance, 123 Financial District, Bandra Kurla Complex, Mumbai, Maharashtra 400051, India
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* FAQ Section */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-semibold mb-4">Frequently Asked Questions</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Find quick answers to common questions about our services
              </p>
            </div>
            
            <div className="max-w-3xl mx-auto">
              <div className="space-y-6">
                {[
                  { 
                    question: "How quickly can I get an insurance quote?", 
                    answer: "You can get an instant quote online for most of our insurance products within minutes. For more complex insurance needs, our advisors will get back to you within 24 hours." 
                  },
                  { 
                    question: "How do I file a claim?", 
                    answer: "You can file a claim online through your account dashboard, call our 24/7 claims helpline at 1800-266-0101, or email the details to claims@easesure.com." 
                  },
                  { 
                    question: "What documents do I need to buy insurance?", 
                    answer: "The required documents vary by insurance type. Generally, you'll need identity proof, address proof, and specific documents relevant to the insurance (e.g., vehicle registration for car insurance)." 
                  }
                ].map((faq, index) => (
                  <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
                    <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default ContactUs;
