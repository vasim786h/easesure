
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Heart, Car, Home, Plane, Briefcase, Shield, CheckCircle } from "lucide-react";

const Services = () => {
  const insuranceServices = [
    {
      title: "Health Insurance",
      description: "Comprehensive health coverage for individuals and families with cashless claims at 10,000+ hospitals nationwide.",
      icon: <Heart className="h-12 w-12 text-white" />,
      color: "bg-red-500",
      benefits: [
        "Cashless treatment at 10,000+ network hospitals",
        "Coverage for pre and post hospitalization expenses",
        "No-claim bonus and cumulative benefits",
        "Coverage for daycare procedures"
      ],
      link: "/learn/health"
    },
    {
      title: "Car Insurance",
      description: "Protect your vehicle with comprehensive coverage, roadside assistance, and quick claim settlement.",
      icon: <Car className="h-12 w-12 text-white" />,
      color: "bg-blue-500",
      benefits: [
        "Comprehensive coverage against damages and theft",
        "24/7 roadside assistance",
        "Cashless repairs at network garages",
        "No claim bonus benefits up to 50%"
      ],
      link: "/motor"
    },
    {
      title: "Home Insurance",
      description: "Secure your home against natural disasters, theft, and damage with our comprehensive plans.",
      icon: <Home className="h-12 w-12 text-white" />,
      color: "bg-green-500",
      benefits: [
        "Coverage against natural disasters and man-made calamities",
        "Protection for household contents and valuables",
        "Coverage for third-party liability",
        "Home assistance services"
      ],
      link: "/business"
    },
    {
      title: "Travel Insurance",
      description: "Enjoy your trips worry-free with coverage for medical emergencies, trip cancellations, and more.",
      icon: <Plane className="h-12 w-12 text-white" />,
      color: "bg-yellow-500",
      benefits: [
        "International medical coverage up to $500,000",
        "Coverage for trip cancellation and interruption",
        "Lost baggage and passport assistance",
        "24/7 global emergency assistance"
      ],
      link: "/travel"
    },
    {
      title: "Business Insurance",
      description: "Tailored insurance solutions for businesses of all sizes to protect against various risks.",
      icon: <Briefcase className="h-12 w-12 text-white" />,
      color: "bg-purple-500",
      benefits: [
        "Property and asset protection",
        "Business interruption coverage",
        "Liability insurance for businesses",
        "Employee benefits and group health policies"
      ],
      link: "/business"
    },
    {
      title: "Life Insurance",
      description: "Secure your family's financial future with our range of life insurance plans and investment options.",
      icon: <Shield className="h-12 w-12 text-white" />,
      color: "bg-easesure-secondary",
      benefits: [
        "Term insurance with high coverage at affordable premiums",
        "Investment plans with insurance protection",
        "Retirement planning solutions",
        "Child education and marriage planning policies"
      ],
      link: "/life"
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-r from-easesure-primary to-easesure-secondary text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Insurance Services</h1>
              <p className="text-xl opacity-90">
                Comprehensive insurance solutions tailored to your specific needs
              </p>
            </div>
          </div>
        </section>
        
        {/* Services Section */}
        <section className="py-16">
          <div className="container">
            <div className="grid grid-cols-1 gap-16">
              {insuranceServices.map((service, index) => (
                <div key={index} className={`grid md:grid-cols-2 gap-8 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
                  <div className="flex flex-col justify-center">
                    <div className={`${service.color} w-20 h-20 rounded-2xl flex items-center justify-center mb-6`}>
                      {service.icon}
                    </div>
                    <h2 className="text-3xl font-semibold mb-4">{service.title}</h2>
                    <p className="text-gray-600 mb-6">{service.description}</p>
                    <ul className="space-y-3 mb-6">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-easesure-primary mr-2 mt-0.5" />
                          <span className="text-gray-700">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                    <div>
                      <Link to={service.link}>
                        <Button className="bg-easesure-primary hover:bg-easesure-secondary">Learn More</Button>
                      </Link>
                    </div>
                  </div>
                  <div className="bg-gray-100 rounded-xl flex items-center justify-center min-h-[300px]">
                    <div className="text-easesure-primary text-lg font-medium">Service Image Placeholder</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-gray-50">
          <div className="container">
            <div className="bg-gradient-to-r from-easesure-primary to-easesure-secondary rounded-xl p-8 md:p-12 text-white text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to find the right insurance plan?</h2>
              <p className="text-xl mb-6 max-w-2xl mx-auto">
                Our advisors are here to help you choose the perfect insurance solution for your needs
              </p>
              <Link to="/get-insurance">
                <Button className="bg-white text-easesure-primary hover:bg-gray-100 transition-colors text-lg px-8 py-6">
                  Get a Free Quote
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Services;
